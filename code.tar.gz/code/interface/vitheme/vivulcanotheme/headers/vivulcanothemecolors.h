#ifndef VIVULCANOTHEMECOLORS_H
#define VIVULCANOTHEMECOLORS_H

#include "vithemecolors.h"

class ViVulcanoThemeColors : public ViThemeColors
{
	public:

		ViVulcanoThemeColors();

};

#endif
