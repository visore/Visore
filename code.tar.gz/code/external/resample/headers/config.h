/* src/config.h.  Generated from configtemplate.h by configure.  */
/* Run configure to generate config.h automatically on any
   system supported by GNU autoconf.  For all other systems,
   use this file as a template to create config.h
*/

#define HAVE_INTTYPES_H 1

