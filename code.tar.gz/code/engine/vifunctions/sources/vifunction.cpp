#include <vifunction.h>

ViFunction::ViFunction()
{
}

ViFunction::ViFunction(const ViFunction &other)
{
}

ViFunction::~ViFunction()
{
}
