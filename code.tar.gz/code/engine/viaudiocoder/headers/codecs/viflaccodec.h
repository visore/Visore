#ifndef VIFLACCODEC_H
#define VIFLACCODEC_H

#include <viaudiocodec.h>

class ViFlacCodec : public ViAudioCodecHolder<ViFlacCodec>
{

	protected:

		void initialize();

};

#endif
