#ifndef VIWAVECODEC_H
#define VIWAVECODEC_H

#include <viaudiocodec.h>

class ViWaveCodec : public ViAudioCodecHolder<ViWaveCodec>
{

	protected:

		void initialize();

};

#endif
