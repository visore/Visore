#ifndef VIMP3CODEC_H
#define VIMP3CODEC_H

#include <viaudiocodec.h>

class ViMp3Codec : public ViAudioCodecHolder<ViMp3Codec>
{

	protected:

		void initialize();

};

#endif
