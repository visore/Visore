#ifndef VINEURALFACTORY_H
#define VINEURALFACTORY_H

static bool STATIC_BOOLEAN_FALSE = false;
static bool STATIC_BOOLEAN_TRUE = true;

class ViNeuralFactory
{

	public:

		virtual ~ViNeuralFactory();

};

#endif
