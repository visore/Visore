#include <vineuralfactory.h>

ViNeuralFactory::~ViNeuralFactory()
{
}
