#include <vineuralunit.h>

ViNeuralUnit::ViNeuralUnit()
{
}

ViNeuralUnit::ViNeuralUnit(const ViNeuralUnit &other)
{
}

ViNeuralUnit::~ViNeuralUnit()
{
}
