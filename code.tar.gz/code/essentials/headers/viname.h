#ifndef VINAME_H
#define VINAME_H

#include <QString>

class ViName
{

	public:

		virtual QString name(QString replace = "", bool spaced = false);

		static QString formatName(QString name, QString replace = "", bool spaced = false);

};

#endif
